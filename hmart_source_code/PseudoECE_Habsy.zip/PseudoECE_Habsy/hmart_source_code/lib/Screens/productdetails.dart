import 'package:flutter/material.dart';

class ProductDetails extends StatelessWidget {
  final String imgUrl;
  ProductDetails({this.imgUrl});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.only(top: 10),
                decoration: BoxDecoration(color: Colors.white, boxShadow: [
                  BoxShadow(
                      color: Colors.black, spreadRadius: 1.5, blurRadius: 5)
                ]),
                height: MediaQuery.of(context).size.height / 3,
                width: double.infinity,
                child: Image.network(
                  imgUrl,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                margin: EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(color: Colors.white, boxShadow: [
                  BoxShadow(
                      color: Colors.grey, spreadRadius: 1.5, blurRadius: 5)
                ]),
                child: Row(
                  children: [
                    Text(
                      "Product Name",
                      style: TextStyle(fontSize: 25),
                    ),
                    SizedBox(width: 70),
                    Text(
                      "Bottle",
                      style: TextStyle(fontSize: 25),
                    ),
                    SizedBox(width: 5)
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                margin: EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(color: Colors.white, boxShadow: [
                  BoxShadow(
                      color: Colors.grey, spreadRadius: 1.5, blurRadius: 5)
                ]),
                child: Row(
                  children: [
                    Text(
                      "Brand Name",
                      style: TextStyle(fontSize: 25),
                    ),
                    SizedBox(width: 90),
                    Text(
                      "Gucci",
                      style: TextStyle(fontSize: 25),
                    ),
                    SizedBox(width: 5)
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                margin: EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(color: Colors.white, boxShadow: [
                  BoxShadow(
                      color: Colors.grey, spreadRadius: 1.5, blurRadius: 5)
                ]),
                child: Row(
                  children: [
                    Text(
                      "Price",
                      style: TextStyle(fontSize: 25),
                    ),
                    SizedBox(width: 170),
                    Text(
                      "500",
                      style: TextStyle(fontSize: 25),
                    ),
                    SizedBox(width: 5)
                  ],
                ),
              ),
              Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  margin: EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(color: Colors.white, boxShadow: [
                    BoxShadow(
                        color: Colors.grey, spreadRadius: 1.5, blurRadius: 5)
                  ]),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Description",
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                            )),
                        SizedBox(
                          height: 4,
                        ),
                        Text(
                          "1). Fit for regular use: with each bottle weighing 106 gms, made of thick material tested thoroughly for the purpose \n 2). Firmer grip and attractive design: with a pattern of squared checks on the body",
                          style: TextStyle(fontSize: 18),
                        )
                      ]))
            ],
          ),
        ),
      ),
    );
  }
}
