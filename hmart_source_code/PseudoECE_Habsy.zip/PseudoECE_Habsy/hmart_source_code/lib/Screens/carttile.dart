import 'package:flutter/material.dart';

class CartTile extends StatelessWidget {
  final String productName;
  final String brandname;
  final String imgUrl;

  final int price;
  CartTile({this.productName, this.brandname, this.imgUrl, this.price});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      margin: EdgeInsets.only(right: 13),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(4),
        boxShadow: <BoxShadow>[
          BoxShadow(
            offset: Offset(1.0, 1.0),
            spreadRadius: 30,
            blurRadius: 15.0,
            color: Colors.black87.withOpacity(0.05),
          ),
        ],
      ),
      child: Row(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(10),
            child: Image.network(
              imgUrl,
              height: 120,
              fit: BoxFit.cover,
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  productName,
                  style: TextStyle(color: Colors.black87, fontSize: 25),
                ),
                Text(
                  brandname,
                  style:
                      TextStyle(color: Colors.grey, height: 1.5, fontSize: 18),
                ),
                Text(
                  '$price',
                  style:
                      TextStyle(color: Colors.black, height: 1.5, fontSize: 18),
                ),
                Text(
                  "Status: Order dispatched",
                  style: TextStyle(color: Colors.black87, fontSize: 20),
                ),
                SizedBox(
                  height: 8,
                ),
                Row(
                  children: <Widget>[
                    SizedBox(
                      width: 3,
                    ),
                  ],
                ),
                SizedBox(
                  height: 13,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
