import 'package:flutter/material.dart';
import 'package:hmart/Screens/productscreen.dart';

import 'package:hmart/common widgets/SearchWidget.dart';
import 'package:hmart/common widgets/TopPromoSlider.dart';

import 'ProductDetails.dart';
import 'cart.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("H-Mart"),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 5),
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return Cart();
                    },
                  ),
                );
              },
              child: Icon(
                Icons.shopping_cart,
              ),
            ),
          ),
          SizedBox(
            width: 10,
          )
        ],
      ),
      drawer: Drawer(),
      body: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: <Widget>[
              SearchWidget(),
              TopPromoSlider(),
              SizedBox(
                height: 10,
                child: Container(
                  color: Color(0xFFf5f6f7),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) {
                        return ProductDetails(
                            imgUrl:
                                "https://images-na.ssl-images-amazon.com/images/I/91q%2BRvk-fFL._AC_SX425_.jpg");
                      },
                    ),
                  );
                },
                child: ProductTile(
                    productName: "Bottle",
                    brandname: "Gucci",
                    imgUrl:
                        "https://images-na.ssl-images-amazon.com/images/I/91q%2BRvk-fFL._AC_SX425_.jpg",
                    price: 500),
              ),
              SizedBox(height: 10),
              ProductTile(
                  productName: "Bottle",
                  brandname: "Gucci",
                  imgUrl:
                      "https://images-na.ssl-images-amazon.com/images/I/91q%2BRvk-fFL._AC_SX425_.jpg",
                  price: 500),
              SizedBox(height: 10),
              ProductTile(
                  productName: "Bottle",
                  brandname: "Gucci",
                  imgUrl:
                      "https://images-na.ssl-images-amazon.com/images/I/91q%2BRvk-fFL._AC_SX425_.jpg",
                  price: 500),
            ],
          ),
        ),
      ),
    );
  }
}
