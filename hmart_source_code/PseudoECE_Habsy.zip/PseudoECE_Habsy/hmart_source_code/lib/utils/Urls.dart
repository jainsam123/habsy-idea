class Urls {

static const ROOT_URL="https://api.evaly.com.bd/core/public/";
}
