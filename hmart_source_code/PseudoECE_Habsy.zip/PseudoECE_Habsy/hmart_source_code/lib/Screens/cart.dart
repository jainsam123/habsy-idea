import 'package:flutter/material.dart';

import 'ProductDetails.dart';
import 'carttile.dart';

class Cart extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Cart"),
      ),
      body: SingleChildScrollView(
          child: Column(
        children: [
          SizedBox(height: 10),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return ProductDetails(
                        imgUrl:
                            "https://images-na.ssl-images-amazon.com/images/I/91q%2BRvk-fFL._AC_SX425_.jpg");
                  },
                ),
              );
            },
            child: CartTile(
                productName: "Bottle",
                brandname: "Gucci",
                imgUrl:
                    "https://images-na.ssl-images-amazon.com/images/I/91q%2BRvk-fFL._AC_SX425_.jpg",
                price: 500),
          ),
        ],
      )),
    );
  }
}
