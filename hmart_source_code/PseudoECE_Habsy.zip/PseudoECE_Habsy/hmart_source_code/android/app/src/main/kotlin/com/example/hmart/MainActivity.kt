package com.example.hmart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
